package com.news.content.controller;

import com.news.content.dao.ContentRepository;
import com.news.content.model.Content;
import com.news.content.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(Constants.CONTENT_VIEW)
public class ContentViewController {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private ContentRepository contentRepository;

    @RequestMapping(value = "/all",
            method = RequestMethod.GET)
    public ModelAndView getAllContents(Model model) {
        logger.info("Get all contents view ...");
        ModelAndView mv = new ModelAndView(Constants.CONTENT_LIST_VIEW);
        return mv;
    }

    @RequestMapping(value = Constants.GET_CONTENT_BY_ID,
            method = RequestMethod.GET)
    public ModelAndView getContentById(@PathVariable("id") Long id) {
        logger.info("Get content id :" + id);
        Content content = contentRepository.findById(id).get();
        ModelAndView mv = new ModelAndView("content");
        mv.addObject("content", content);
        return mv;
    }

    @RequestMapping(value = Constants.UPDATE_CONTENT,
            method = RequestMethod.PUT)
    public ModelAndView updateContent(@RequestParam Content content) {
        logger.info("Update content id :" + content.getId());
        Content contentUpdated =  contentRepository.save(content);
        ModelAndView mv = new ModelAndView("content");
        mv.addObject("content", contentUpdated);
        return mv;
    }

    @RequestMapping(value = Constants.DELETE_CONTENT,
            method = RequestMethod.DELETE)
    public String deleteContent(@PathVariable("id") Long contentId) {
        logger.info("Delete content id :" + contentId);
        contentRepository.deleteById(contentId);
        return "redirect:" + Constants.CONTENT_LIST_VIEW;
    }

}
