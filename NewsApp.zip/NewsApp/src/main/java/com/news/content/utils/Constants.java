package com.news.content.utils;

public interface Constants {
    String LOGIN_USER = "user";
    String LOGIN_PASSWORD = "password123";
    String CONTENT_VIEW_WO_SLASH = "contentview";
    String CONTENT_VIEW = "/contentview";
    String GET_CONTENT_BY_ID = "/getcontent/{id}";
    String UPDATE_CONTENT = "/update";
    String DELETE_CONTENT = "/delete/{id}";
    String CONTENT_LIST_VIEW = "contents_list";
    String CONTENT_URL = "/content";
    String CONTENT_ALL_URL = "content/all";
}
