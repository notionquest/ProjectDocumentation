package com.news.content.dao;

import com.news.content.model.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {

    List<User> findByUserNameAndPassword(String userName, String password);
}
