package com.news.content.utils;

import org.apache.commons.codec.digest.DigestUtils;

import java.io.UnsupportedEncodingException;

public class CommonUtils {

    public static String getDatabasePassword(String plainText)
            throws UnsupportedEncodingException
    {
        byte[] utf8 = plainText.getBytes("UTF-8");
        return "*" + DigestUtils.shaHex(DigestUtils.sha(utf8)).toUpperCase();
    }
}
