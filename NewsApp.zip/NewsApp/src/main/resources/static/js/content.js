function submitContentForm(url, method) {
    alert('cancel');
    $("#contentForm").attr('action', url);
    $("#contentForm").attr('method', method);
    $("#contentForm").submit();
}

function submitDeleteContent() {
    alert('delete');
    var contentId = $("#contentId").val();
    $("#contentForm").attr('action', '/contentview/delete/' + contentId);
    $("#contentForm").attr('method', 'DELETE');
    $("#contentForm").submit();
}