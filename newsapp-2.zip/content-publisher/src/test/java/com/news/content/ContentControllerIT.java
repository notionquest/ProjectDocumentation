package com.news.content;

public class ContentControllerIT {
}
