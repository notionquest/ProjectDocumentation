package com.news.content.controller;

import com.news.content.model.Content;
import com.news.content.model.ContentStatus;
import com.news.content.utils.ClientUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.net.URL;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ContentControllerIT {

    private Logger logger = LoggerFactory.getLogger(getClass());

    //@LocalServerPort
    private int port;

    private URL base;

    @Rule
    public ExpectedException thrown= ExpectedException.none();

    @Autowired
    private TestRestTemplate template;

    private RestTemplate restTemplate;

    @Autowired
    private ClientUtils clientUtils;

    @Before
    public void setUp() throws Exception {
        this.base = new URL("http://localhost:" + port + "/content");
        restTemplate = new RestTemplate();
    }

    private Content getContent() {
        ParameterizedTypeReference<List<Content>> typeRef = new ParameterizedTypeReference<List<Content>>() {
        };

        ResponseEntity<List<Content>> response = template.exchange(base.toString(),
                HttpMethod.GET,
                clientUtils.getHttpEntity(null),
                typeRef,
                Collections.emptyMap());

        return response.getBody().stream().findFirst().get();
    }


    private Content getContentById(Long contentId) {

        ResponseEntity<Content> response = template.exchange(base.toString() + "/get/" + contentId,
                HttpMethod.GET,
                clientUtils.getHttpEntity(null),
                Content.class,
                Collections.emptyMap());

        return response.getBody();
    }

    @Test
    public void saveContent() {
        Content content = new Content();
        content.setBody("test body");
        content.setStatus(ContentStatus.INPROGRESS.toString());
        content.setTitle("test title");
        ResponseEntity<Content> response = template.postForEntity(base.toString(),
                clientUtils.getHttpEntity(content),
                Content.class,
                Collections.emptyMap());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody().getId());
        assertNotNull(response.getBody());

    }


    @Test
    public void getContents() {
        ResponseEntity<String> response = template.getForEntity(base.toString(),
                String.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void updateContent() {
        ParameterizedTypeReference<List<Content>> typeRef = new ParameterizedTypeReference<List<Content>>() {
        };
        ResponseEntity<List<Content>> response = template.exchange(base.toString(),
                HttpMethod.GET,
                clientUtils.getHttpEntity(null),
                typeRef, Collections.emptyMap());
        List<Content> contents = response.getBody();
        assertNotNull(contents);
        assertTrue(contents.size() > 0);

        Content content = contents.stream().findFirst().get();

        content.setTitle("New Title");
        ResponseEntity<Content> responseUpd = template.exchange(base.toString(), HttpMethod.PUT,
                clientUtils.getHttpEntity(content),
                Content.class);
        assertNotNull(responseUpd.getBody());
        assertEquals("New Title", responseUpd.getBody().getTitle());
    }

    @Test
    public void deleteContentById() {
        Content content = getContent();
        logger.info("Delete the content :" + content.getId());

        //template.delete(base.toString() + "/delete/" + content.getId());
        String url = base.toString() + "/delete/" + content.getId();
        restTemplate.delete(url);
        /*restTemplate.exchange(base.toString() + "/delete/1"
                , HttpMethod.DELETE
                ,null,String.class, Collections.emptyMap());*/

        //thrown.expect(ResourceNotFoundException.class);
        //getContentById(content.getId());

    }
}
