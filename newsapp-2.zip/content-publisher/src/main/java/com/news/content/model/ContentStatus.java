package com.news.content.model;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum ContentStatus {
    INPROGRESS("INPROGRESS"), PUBLISHED("PUBLISHED");

    private final String contentStatus;

    ContentStatus(String contentStatus) {
        this.contentStatus = contentStatus;
    }

    public String getContentStatus() {
        return contentStatus;
    }

    @Override
    public String toString() {
        return contentStatus; 
    }

    @JsonCreator
    public static ContentStatus create(String contentStatus) {
        if (contentStatus == null) {
            throw new IllegalArgumentException();
        }
        for (ContentStatus v : ContentStatus.values()) {
            if (v.getContentStatus().equals(contentStatus)) {
                return v;
            }
        }
        throw new IllegalArgumentException();
    }

}
