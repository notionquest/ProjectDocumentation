package com.news.content.controller;

import com.news.content.dao.UserRepository;
import com.news.content.model.User;
import com.news.content.model.UserForm;
import com.news.content.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.UnsupportedEncodingException;
import java.util.List;

@Controller("/users")
public class UserController {

    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private UserRepository userRepository;

/*    @Autowired
    private PasswordEncoder passwordEncoder;*/

    @PostMapping(name = "/checkuser", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String checkUser(@ModelAttribute UserForm userForm) {

        logger.info("Check user");

        try {
            List<User> user = userRepository
                    .findByUserNameAndPassword(userForm.getUserId(),
                            CommonUtils.getDatabasePassword(userForm.getPassword()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return "redirect:contentview" +"/all";
    }

}
