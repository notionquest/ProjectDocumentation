package com.news.content.utils;

public interface Constants {
    String LOGIN_USER = "user";
    String LOGIN_PASSWORD = "password123";
    String CONTENT_VIEW = "/contentview";
}
