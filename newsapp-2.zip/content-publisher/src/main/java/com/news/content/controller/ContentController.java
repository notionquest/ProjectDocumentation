package com.news.content.controller;

import com.news.content.dao.ContentRepository;
import com.news.content.model.Content;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController("/content")
public class ContentController {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private ContentRepository contentRepository;

    @GetMapping("/all")
    //@GetMapping
    public Iterable<Content> getAllContents() {
        return contentRepository.findAll();
    }

    @GetMapping("/get/{id}")
    public Content getContentById(@PathVariable("id") Long id) {
        return contentRepository.findOne(id);
    }


    @PostMapping
    public Content create(@RequestBody Content content) {
        return contentRepository.save(content);
    }

    @PutMapping
    public Content update(@RequestBody Content content) {
        return contentRepository.save(content);
    }

    //@DeleteMapping("/delete/{id}")
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public @ResponseBody void deleteById(@PathVariable("id") Long id) {
        contentRepository.delete(id);
    }

}
