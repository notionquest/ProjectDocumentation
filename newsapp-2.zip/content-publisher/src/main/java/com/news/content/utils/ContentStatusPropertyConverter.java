package com.news.content.utils;

public class ContentStatusPropertyConverter {//extends PropertyEditor {

    /*@Override
    public void setAsText(String text) throws IllegalArgumentException {
        setValue(ContentStatus.valueOf());
    }*/
}
