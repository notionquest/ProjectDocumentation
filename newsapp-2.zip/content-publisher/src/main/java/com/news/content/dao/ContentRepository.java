package com.news.content.dao;

import com.news.content.model.Content;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ContentRepository extends PagingAndSortingRepository<Content, Long> {
}
