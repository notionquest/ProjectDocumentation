package com.news.content.model;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class ContentStatusConverter
        implements AttributeConverter<ContentStatus, String> {

    @Override
    public String convertToDatabaseColumn(ContentStatus contentStatus) {
        switch (contentStatus) {
            case INPROGRESS:
                return "IN";
            case PUBLISHED:
                return "PUB";
            default:
                throw new IllegalArgumentException("Unknown content status :" + contentStatus);
        }
    }

    @Override
    public ContentStatus convertToEntityAttribute(String contentStatus) {
        switch (contentStatus) {
            case "IN":
                return ContentStatus.INPROGRESS;
            case "PUB":
                return ContentStatus.PUBLISHED;
            default:
                throw new IllegalArgumentException("Unknown content status :" + contentStatus);
        }
    }
}
