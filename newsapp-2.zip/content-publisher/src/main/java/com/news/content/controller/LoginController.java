package com.news.content.controller;

import com.news.content.model.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.Locale;

@Controller
public class LoginController {

    @RequestMapping(value="/",method = RequestMethod.GET)
    public String home(){
        return "app_login";
    }

    //@RequestMapping(method= RequestMethod.GET, value = "/home")
    @GetMapping("/home")
    public ModelAndView login(Locale locale, Model model) {
        ModelAndView mv = new ModelAndView("app_login");
        mv.addObject("user", new UserForm());
        return mv;
    }
}
