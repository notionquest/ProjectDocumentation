INSERT INTO news.content (body ,
                              create_date ,
                              last_modified_date ,
                              status,
                              title)
    VALUES ('test body',
    now(),
    now(),
    'INPROGRESS',
    'test title'
    );