CREATE SCHEMA IF NOT EXISTS news;

CREATE USER 'newsuser'@'%' IDENTIFIED BY 'password1';
GRANT ALL PRIVILEGES ON *.* TO 'newsuser'@'%'
         WITH GRANT OPTION;
         
CREATE TABLE news.user (
  id int NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL,
  last_name varchar(100) NOT NULL,
  user_name varchar(100) NOT NULL,
  role varchar(100) NOT NULL,
  password varchar(200) NOT NULL,  
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;         

GRANT ALL ON news.user TO 'newsuser'@'%';

INSERT INTO news.user
	(first_name, last_name, user_name, password, role) VALUES
                   ('SUPER ADMIN', 'admin', 'admin', PASSWORD('admin'), 'publisher'),
                   ('robin', 'robin', 'robin', PASSWORD('admin'), 'viewer'),
                   ('mark', 'taylor', 'mark', PASSWORD('mark'), 'viewer'),
                   ('james', 'taylor', 'james', PASSWORD('mark'), 'publisher');
                   
Commit;                   