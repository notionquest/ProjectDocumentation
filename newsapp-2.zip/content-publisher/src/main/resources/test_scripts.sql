Drop table news.content;
Drop table news.employee;

Select * from news.content;
Select count(*) from news.content;

Select * from news.employee;