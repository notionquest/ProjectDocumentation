CREATE TABLE IF NOT EXISTS news.content (
    id int(11) not null AUTO_INCREMENT,
    body text,
    create_date datetime,
    last_modified_date datetime,
    pub_time datetime,
    status varchar(255),
    title varchar(255),
    primary key (id)
);

GRANT ALL ON news.content TO 'newsuser'@'%';
